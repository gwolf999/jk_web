 // 还有运算后一下后再连续++等bug及有理数无理数显示未处理
    cal_num = new Array('', '', '');
    // 声明一个全局变量的二维数组，其实可以不用
    /* cal_num[0]=new Array();
     cal_num[1]='';
     cal_num[2]=new Array();*/
   
    // 运算处理函数，使用修改全局变量的方法
    function char_pro(y) {
        switch (y) {
            case '.':
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
                if (cal_num[1].length == 0) {
                    cal_num[0] = cal_num[0] + y;
                    document.getElementById("cal_span").innerHTML = check_len(cal_num[0]);
                } else {
                    cal_num[2] = cal_num[2] + y;
                    document.getElementById("cal_span").innerHTML = check_len(cal_num[2]);
                }
                break;
            case '+':
                cal_num[1] = y;
                document.getElementById("cal_span").innerHTML = cal_num[1];
                break;
            case '-':
                cal_num[1] = y;
                document.getElementById("cal_span").innerHTML = cal_num[1];
                break;
            case 'X':
                cal_num[1] = y;
                document.getElementById("cal_span").innerHTML = cal_num[1];
                break;
            case '/':
                cal_num[1] = y;
                document.getElementById("cal_span").innerHTML = cal_num[1];
                break;
            case 'C':
                cal_num[0] = '';
                cal_num[1] = '';
                cal_num[2] = '';
                console.log('cal_numC:' + cal_num[0]);
                document.getElementById("cal_span").innerHTML = cal_num[0];
                break;

            default: //  等号情况 Infinity

                document.getElementById("cal_span").innerHTML = cal_num[0] + cal_num[1] + cal_num[2];

                console.log("数组一位数为：" + cal_num[0].length);
                console.log("数组二位数为：" + cal_num[1].length);
                console.log("数组三位数为：" + cal_num[2].length);
                
                            
                if (cal_num[1] == '+') {

                    document.getElementById("cal_span").innerHTML =  check_len((cal_num[0]-0) + (cal_num[2]-0));

                    store_equ(cal_num[1]);

                } else if (cal_num[1] == '-') {
                    document.getElementById("cal_span").innerHTML = cal_num[0] - cal_num[2];
                    store_equ(cal_num[1]);
                } else if (cal_num[1] == 'X') {
                	// tmp=check_len(String(cal_num[0] * cal_num[2]));
                	//  console.log('tmp1='+tmp);
                	// check_len(tmp);
                	//  console.log('tmp2='+tmp);
                	//check_len(String(cal_num[0] * cal_num[2]));必须要转换为String否则监测不了数值型的长度。
                     document.getElementById("cal_span").innerHTML = check_len(String(cal_num[0] * cal_num[2]));
                    
                    store_equ(cal_num[1]);
                } else if (cal_num[1] == '/') {
                    document.getElementById("cal_span").innerHTML = check_len(cal_num[0] / cal_num[2]);
                    store_equ(cal_num[1]);
                } else {
                    if (cal_num[2] != '') {
                    
                        document.getElementById("cal_span").innerHTML =  check_len(cal_num[0] / cal_num[2]);
                        store_equ(cal_num[1]);
                    } else {
                        // 针对连续按等号情况
                        cal_num[0] = '';
                        cal_num[1] = '';
                        cal_num[2] = '';
                        console.log('cal_numC:' + cal_num[0]);
                        document.getElementById("cal_span").innerHTML = cal_num[0];


                    };
                };

                break;

        };

    };

    // 把按等号以后的运行结果存储到第一参数去，方便连续计算
    function store_equ(f) {
        switch (f) {
            case '+':
                cal_num[0] = (cal_num[0] - 0) + (cal_num[2] - 0);
                cal_num[1] = '';
                cal_num[2] = '';
                break;
            case '-':
                cal_num[0] = check_len(cal_num[0] - cal_num[2]);
                cal_num[1] = '';
                cal_num[2] = '';
                break;
            case 'X':
                cal_num[0] = check_len(cal_num[0] * cal_num[2]);
                cal_num[1] = '';
                cal_num[2] = '';
                break;
            case '/':
                cal_num[0] = check_len(cal_num[0] / cal_num[2]);
                cal_num[1] = '';
                cal_num[2] = '';
                break;

        }

    };

    // 检查输入数的长度，超过10位报错,否则返回原值
    function check_len(z) {
               console.log('z-type:'+typeof(z));
        // indexOf(),出现位置从0开始计算
        if (typeof(z)=="number") {
        	// z如果是数值，把先转换为字符串求出的长度减去小数点后长度，因为从0开始再减1；然后按10这个长度作为数值z的小数点后尾数返回
         //    console.log('z-n1='+z);
         //    console.log(String(z).length-String(z).indexOf('.')-1);
         //    var t=0;
        	// // t = z.toFixed(String(z).length-String(z).indexOf('.')-1);
        	// t = z.toFixed(10-String(z).indexOf('.')-1);
         //     console.log('z-n2='+t);
            if(String(z).indexOf('.')==-1){
            	// 如果是整数就直接返回
            	return z;

            }else{
            	// 返回截取相应长度的小数位置
            	return z.toFixed(10-String(z).indexOf('.')-1)
            };
        }else{
        	console.log('z-str=:'+z);
        	return (z.length > 10) ? "ERROR" : z;
        }

        

    }



// 调用处理函数，可拓展
    function inputnumber(x) {
        char_pro(x);
        // alert(x);
        // var n = document.getElementById("cal_span").innerHTML;
        // console.log("n=" + n);
        // console.log(n.length);
        // console.log(typeof(n));
        // console.log('x=' + typeof(x));
        // if (n == '' && typeof(x) != 'number') {
        //     // alert("请输入数字");
        //     return "False"
        // }
        // // c默认的值显示框为空
        // if (x === 'c') {
        //     // document.getElementById("cal_span").innerHTML = '';
        // } else {
        //     // innerHTML严格区分大小写
        //     // document.getElementById("cal_span").innerHTML = x;
        //     console.log("n2=" + n);
        // }
    };